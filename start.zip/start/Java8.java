package com.streams.start;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.streams.model.Dish;

public class Java8
{
    static List<Dish> menu = Arrays.asList(new Dish("mutton", false, 800, Dish.Type.MEAT),
                                           new Dish("idli", true, 200, Dish.Type.OTHER),
                                           new Dish("chicken", false, 400, Dish.Type.MEAT),
                                           new Dish("french fries", true, 530, Dish.Type.OTHER),
                                           new Dish("rice", true, 350, Dish.Type.OTHER),
                                           new Dish("season fruit", true, 120, Dish.Type.OTHER),
                                           new Dish("pizza", true, 550, Dish.Type.OTHER),
                                           new Dish("prawns", false, 500, Dish.Type.FISH),
                                           new Dish("beef", false, 700, Dish.Type.MEAT),
                                           new Dish("salmon", false, 450, Dish.Type.FISH));

    public static void main(String[] args)
    {
        List<String> lowCalorieDishNames = menu.stream()
                .filter(d -> d.getCalories() < 400)
                .sorted(Comparator.comparing(d -> d.getName()))
                .map(d -> d.getName())
                .collect(Collectors.toList());

        lowCalorieDishNames.forEach(s -> System.out.println(s));

         List<String> lowCalorieDishNamesParallel = menu.parallelStream()
                .filter(d -> d.getCalories() < 400)
                .sorted(Comparator.comparing(d -> d.getName()))
                .map(d -> d.getName())
                .collect(Collectors.toList());
        
        lowCalorieDishNamesParallel.forEach(s->System.out.println(s));
    }
}
