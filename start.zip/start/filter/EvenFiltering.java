package com.streams.start.filter;

import java.util.Arrays;
import java.util.List;
import static java.util.stream.Collectors.toList;

import com.streams.model.Dish;

public class EvenFiltering
{
    static List<Dish> menu = Arrays.asList(new Dish("mutton", false, 800, Dish.Type.MEAT),
                                           new Dish("idli", true, 200, Dish.Type.OTHER),
                                           new Dish("chicken", false, 400, Dish.Type.MEAT),
                                           new Dish("french fries", true, 530, Dish.Type.OTHER),
                                           new Dish("rice", true, 350, Dish.Type.OTHER),
                                           new Dish("season fruit", true, 120, Dish.Type.OTHER),
                                           new Dish("pizza", true, 550, Dish.Type.OTHER),
                                           new Dish("prawns", false, 500, Dish.Type.FISH),
                                           new Dish("beef", false, 700, Dish.Type.MEAT),
                                           new Dish("salmon", false, 450, Dish.Type.FISH));

    public static void main(String[] args)
    {
        List<Integer> numbers = Arrays.asList(1,
                                              2,
                                              1,
                                              3,
                                              3,
                                              2,
                                              4);
        numbers.stream()
                .filter(i -> i % 2 == 0)
                .distinct()
                .forEach(System.out::println);

        List<Dish> dishes = menu.stream()
                .filter(d -> d.getCalories() > 300)
                .limit(3)
                .collect(toList());
        dishes.forEach(c -> System.out.println(c));

        System.out.println("Skipping");
        menu.stream()
                .filter(d -> d.getCalories() > 300)
                .skip(2)
                .forEach(c -> System.out.println(c));
    }
}
