package com.streams.start;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class StreamTraverse
{
    public static void main(String[] args)
    {
        List<String>   title = Arrays.asList("Java8",
                                             "in",
                                             "action");
        Stream<String> s     = title.stream();
        s.forEach(c -> System.out.println(c));
        s.forEach(c -> System.out.println(c));
    }
}
