package com.streams.start;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.streams.model.Dish;

public class Java7
{
    static List<Dish> menu = Arrays.asList(new Dish("mutton", false, 800, Dish.Type.MEAT),
                                           new Dish("idli", true, 200, Dish.Type.OTHER),
                                           new Dish("chicken", false, 400, Dish.Type.MEAT),
                                           new Dish("french fries", true, 530, Dish.Type.OTHER),
                                           new Dish("rice", true, 350, Dish.Type.OTHER),
                                           new Dish("season fruit", true, 120, Dish.Type.OTHER),
                                           new Dish("pizza", true, 550, Dish.Type.OTHER),
                                           new Dish("prawns", false, 500, Dish.Type.FISH),
                                           new Dish("beef", false, 700, Dish.Type.MEAT),
                                           new Dish("salmon", false, 450, Dish.Type.FISH));

    public static void main(String[] args)
    {
        List<Dish> lowCalorieDishes = new ArrayList<Dish>();
        for (Dish d : menu)
        {
            if (d.getCalories() < 400) lowCalorieDishes.add(d);
        }

        Collections.sort(lowCalorieDishes,
                         new Comparator<Dish>()
                         {

                             @Override
                             public int compare(Dish d1, Dish d2)
                             {
                                 return Integer.compare(d1.getCalories(),
                                                        d2.getCalories());
                             }
                         });

        List<String> lowCalorieDishNames = new ArrayList<String>();
        for (Dish d : lowCalorieDishes)
            lowCalorieDishNames.add(d.getName());

        System.out.println(lowCalorieDishNames);
    }
}
