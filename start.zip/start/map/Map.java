package com.streams.start.map;

import java.util.Arrays;
import java.util.List;
import static java.util.stream.Collectors.toList;

import com.streams.model.Dish;

public class Map
{
    static List<Dish> menu = Arrays.asList(new Dish("mutton", false, 800, Dish.Type.MEAT),
                                           new Dish("idli", true, 200, Dish.Type.OTHER),
                                           new Dish("chicken", false, 400, Dish.Type.MEAT),
                                           new Dish("french fries", true, 530, Dish.Type.OTHER),
                                           new Dish("rice", true, 350, Dish.Type.OTHER),
                                           new Dish("season fruit", true, 120, Dish.Type.OTHER),
                                           new Dish("pizza", true, 550, Dish.Type.OTHER),
                                           new Dish("prawns", false, 500, Dish.Type.FISH),
                                           new Dish("beef", false, 700, Dish.Type.MEAT),
                                           new Dish("salmon", false, 450, Dish.Type.FISH));

    public static void main(String[] args)
    {
        List<String> dishes = menu.stream()
                .map(d -> d.getName())
                .collect(toList());
        dishes.forEach(c -> System.out.println(c));

        List<Integer> dishNameLengths = menu.stream()
                .map((Dish d) -> d.getName())
                .map(s -> s.length())
                .collect(toList());
        dishNameLengths.forEach(c -> System.out.println(c));

        List<String>  words       = Arrays.asList("Java8",
                                                  "Lambdas",
                                                  "In",
                                                  "Action");
        List<Integer> wordLengths = words.stream()
                .map(s -> s.length())
                .collect(toList());
        wordLengths.forEach(c -> System.out.println(c));

    }
}
