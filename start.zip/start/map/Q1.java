package com.streams.start.map;

import java.util.Arrays;
import java.util.List;
import static java.util.stream.Collectors.toList;

public class Q1
{
    public static void main(String[] args)
    {
        List<Integer> numbers = Arrays.asList(1,
                                              2,
                                              3,
                                              4,
                                              5);
        List<Integer> squares = numbers.stream()
                .map(n -> n * n)
                .collect(toList());

        List<String> list   = Arrays.asList("geeks",
                                            "gfg",
                                            "g",
                                            "e",
                                            "e",
                                            "k",
                                            "s");
        List<String> answer = list.stream()
                .map(String::toUpperCase)
                .collect(toList());

        List<Employee> employeesList = Arrays.asList(new Employee(1, "Alex", 100),
                                                     new Employee(2, "Brian", 100),
                                                     new Employee(3, "Charles", 200),
                                                     new Employee(4, "David", 200),
                                                     new Employee(5, "Edward", 300),
                                                     new Employee(6, "Frank", 300));

        List<Long> distinctSalaries = employeesList.stream()
                .map(e -> e.getSalary())
                .distinct()
                .collect(toList());

        System.out.println(distinctSalaries);
    }
}
