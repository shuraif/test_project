package com.streams.start.map;

import static java.util.stream.Collectors.toList;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import javax.smartcardio.ATR;

public class FlattenStreams
{
    public static void main(String[] args)
    {
        String[]             arrayOfWords  = { "Goodbye", "World" };
        Stream<String>       streamOfwords = Arrays.stream(arrayOfWords);
        List<Stream<String>> split         = streamOfwords.map((String word) -> word.split(""))
                .map(a -> Arrays.stream(a))
                .distinct()
                .collect(toList());
        split.forEach(c -> System.out.println(c));

        Stream<String> streamOfwords1 = Arrays.stream(arrayOfWords);
        List<String>   strList        = streamOfwords1.map(word -> word.split(""))
                .flatMap(w -> Arrays.stream(w))
                .distinct()
                .collect(toList());
        System.out.println(strList);

        List<List<String>> list     = Arrays.asList(Arrays.asList("a"),
                                                    Arrays.asList("b"));
        List<String>       strList1 = list.stream()
                .flatMap(Collection::stream)
                .collect(toList());
        System.out.println(strList1);

        String[][]       strArray       = { { "a", "b" }, { "c", "d" }, { "e", "f" } };
        Stream<String[]> strArrayStream = Arrays.stream(strArray);
        Stream<String>   strStream      = strArrayStream.flatMap(a -> Arrays.stream(a));
        strStream.forEach(s -> System.out.println(s));

    }
}
